const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const db = require('./db');
const XLSX = require('xlsx');

const app = express();
app.use(cors());
app.use(bodyParser.json());

app.post('/register', (req, res) => {
  const { name, username, password } = req.body;
  db.query('INSERT INTO users (name, username, password) VALUES (?, ?, ?)', 
    [name, username, password], (err) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ message: 'Registrasi berhasil, menunggu persetujuan admin' });
    });
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  db.query('SELECT * FROM users WHERE username = ? AND password = ?', 
    [username, password], (err, results) => {
      if (err) return res.status(500).json({ error: err.message });
      if (results.length === 0) return res.status(401).json({ error: 'Login gagal' });
      const user = results[0];
      if (!user.approved && user.role === 'member') {
        return res.status(403).json({ error: 'Akun belum disetujui admin' });
      }
      res.json({ message: 'Login berhasil', user });
    });
});

app.post('/approve', (req, res) => {
  const { userId } = req.body;
  db.query('UPDATE users SET approved = TRUE WHERE id = ?', [userId], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: 'Member disetujui' });
  });
});

app.post('/checkin', (req, res) => {
  const { userId, status } = req.body;
  const now = new Date();
  const today = now.toISOString().slice(0,10);
  db.query('INSERT INTO attendance (user_id, status, checkIn, date) VALUES (?, ?, ?, ?)', 
    [userId, status, now, today], (err) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ message: 'Check-in berhasil' });
    });
});

app.post('/checkout', (req, res) => {
  const { userId } = req.body;
  const now = new Date();
  const today = now.toISOString().slice(0,10);
  db.query('UPDATE attendance SET checkOut = ? WHERE user_id = ? AND date = ? AND checkOut IS NULL', 
    [now, userId, today], (err) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ message: 'Check-out berhasil' });
    });
});

app.get('/attendance', (req, res) => {
  db.query('SELECT a.*, u.name FROM attendance a JOIN users u ON a.user_id = u.id', (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
});

app.get('/export', (req, res) => {
  db.query('SELECT a.*, u.name FROM attendance a JOIN users u ON a.user_id = u.id', (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    const ws = XLSX.utils.json_to_sheet(results);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Absensi');
    const buffer = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
    res.setHeader('Content-Disposition', 'attachment; filename=absensi.xlsx');
    res.send(buffer);
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
