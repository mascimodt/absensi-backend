CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin','member') DEFAULT 'member',
    approved BOOLEAN DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS attendance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    status ENUM('Hadir','Terlambat') NOT NULL,
    checkIn DATETIME,
    checkOut DATETIME,
    date DATE,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

INSERT INTO users (name, username, password, role, approved) VALUES
('Administrator', 'admin', 'admin123', 'admin', TRUE);
